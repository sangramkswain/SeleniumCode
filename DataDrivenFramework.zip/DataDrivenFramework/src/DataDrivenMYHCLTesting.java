import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

public class DataDrivenMYHCLTesting {

	public String baseURL = "https://www.myhcl.com/";
	public WebDriver myhcl_WD;

	@Test(dataProvider = "getData")
	public void supplyCredentials(String userName, String passWord, String domain) {
		System.out.println("username = " + userName);
		System.out.println("passWord = " + passWord);
		System.out.println("domain = " + domain);

		myhcl_WD.findElement(By.xpath(".//*[@id='txtUserID']")).clear();
		myhcl_WD.findElement(By.xpath(".//*[@id='txtPassword']")).clear();
		myhcl_WD.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys(userName);
		myhcl_WD.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys(passWord);
		myhcl_WD.findElement(By.xpath(".//*[@id='ddlDomain']")).sendKeys(domain);
		myhcl_WD.findElement(By.xpath(".//*[@id='btnSubmit']")).click();
	}

	@BeforeMethod
	public void initializeDriver() {
		myhcl_WD = new FirefoxDriver();
		myhcl_WD.manage().window().maximize();
		myhcl_WD.get(baseURL);
	}

	@AfterMethod
	public void cleanUp() {
		myhcl_WD.quit();
	}

	@DataProvider
	public Object[][] getData() {
		Object[][] myHCLCredentials = new Object[2][3];
		myHCLCredentials[0][0] = "Sangram.Swain";
		myHCLCredentials[0][1] = "HCL@123";
		myHCLCredentials[0][2] = "HCLTECH";

		myHCLCredentials[1][0] = "Sangram.Swain";
		myHCLCredentials[1][1] = "Godisgreat@123";
		myHCLCredentials[1][2] = "HCLTECH";

		return myHCLCredentials;
	}

}
