package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class myHCLPage {
	
	WebDriver driver;
	
	public void initBrowser() {
		driver = new FirefoxDriver();
	}
	
	public void navigateToMYHCL() {
		driver.get("https://www.myhcl.com/Login/home.aspx");
	}
	
	public boolean titleValidation() {
		String expectedTitle = "My HCL Login";
		String actualTitle = driver.getTitle();
		
		boolean result = expectedTitle.equals(actualTitle);
		
		return result;
	}

}
