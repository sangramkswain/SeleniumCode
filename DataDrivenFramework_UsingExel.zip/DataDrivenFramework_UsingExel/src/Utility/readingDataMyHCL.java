package Utility;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readingDataMyHCL {
	public String userName;
	public String passWord;
	public String domain;
	public String url;
	
	public static Object[][] readCredentials(String filePath, String fileName, String sheetName) throws Exception{
		File file =    new File(filePath+"\\"+fileName);
		FileInputStream inputStream = new FileInputStream(file);
		
		
		Workbook workbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if(fileExtensionName.equals(".xlsx")){
			System.out.println("XLXS");
			workbook = new XSSFWorkbook(inputStream);			
		}
		else if (fileExtensionName.equals(".xls")){
			workbook =  new HSSFWorkbook(inputStream);
		}
		
		Sheet sheet = workbook.getSheet(sheetName);
		int rowCount = sheet.getPhysicalNumberOfRows();
		
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		
		Object[][] testData = new Object[rowCount-1][colCount]; 
		
		
		
		for (int i = 1; i < rowCount; i++){
			for (int j = 0; j < colCount; j++) {
				testData[i-1][j] = sheet.getRow(i).getCell(j).getStringCellValue();
			}			
		}
		return testData;
		
	}
	

}
