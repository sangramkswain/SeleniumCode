import org.testng.annotations.Test;

import Utility.readingDataMyHCL;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

public class DDFUsingExcel {
	
	public String baseURL = "https://www.myhcl.com/";
	public WebDriver myhcl_WD;
	
	@Test(dataProvider = "getData")
	public void supplyCredentials(String userName, String passWord, String domain) {
		System.out.println("username = " + userName);
		System.out.println("passWord = " + passWord);
		System.out.println("domain = " + domain);

		myhcl_WD.findElement(By.xpath(".//*[@id='txtUserID']")).clear();
		myhcl_WD.findElement(By.xpath(".//*[@id='txtPassword']")).clear();
		myhcl_WD.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys(userName);
		myhcl_WD.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys(passWord);
		myhcl_WD.findElement(By.xpath(".//*[@id='ddlDomain']")).sendKeys(domain);
		myhcl_WD.findElement(By.xpath(".//*[@id='btnSubmit']")).click();
	}

  @BeforeMethod
  public void initDriver() {
	  myhcl_WD = new FirefoxDriver();
		myhcl_WD.manage().window().maximize();
		myhcl_WD.get(baseURL);
  }

  @AfterMethod
  public void afterMethod() {
	  myhcl_WD.quit();
  }
  
  @DataProvider
	public Object[][] getData() throws Exception {
		Object[][] myHCLCredentials = new Object[2][2];
		//readCredentials(String filePath, String fileName, String sheetName)
		myHCLCredentials = readingDataMyHCL.readCredentials("D:\\Users\\sangram.swain\\eclipse-workspace\\DataDrivenFramework_UsingExel", "TestData.xlsx", "Credentials");
		

		return myHCLCredentials;
	}

}
