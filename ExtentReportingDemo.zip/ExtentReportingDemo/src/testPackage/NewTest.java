package testPackage;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility.CommonFunction;

public class NewTest {
	WebDriver driver;
	ExtentReports extent ;
	ExtentTest log;
	
 @BeforeTest
	  public void beforeTest() {
		  extent = new ExtentReports("D:\\Users\\sangram.swain\\eclipse-workspace\\ExtentReportingDemo\\Report\\TestReport.html");
		  extent.loadConfig(new File("D:\\Users\\sangram.swain\\eclipse-workspace\\ExtentReportingDemo\\Resource\\extent-config.xml"));
		  extent.addSystemInfo("Project", "HCL Automation");
		  driver = new FirefoxDriver(); 
		  driver.get("https://www.myhcl.com/Login/home.aspx");
	  }
	
  @Test
  public void validateTitle() throws IOException {
	  log = extent.startTest("Starting Test case excecution - validateTitle");
	  String expected = "My HCL Login";
	  String actual = driver.getTitle();
	  String capturePath = CommonFunction.captureScreenShotAndGetPath(driver, "hclHomePage");
	  Assert.assertEquals(expected, actual);
	  
	  log.log(LogStatus.PASS, "Title check pass with Screenshot"+log.addScreenCapture(capturePath));
  }
  
  @Test
  public void testPresenceOfUIField() throws IOException {
	  log = extent.startTest("Starting Test case excecution - testPresenceOfUIField");
	  WebElement element = driver.findElement(By.xpath(".//*[@id='txtUserID']"));
	  boolean result = element.isDisplayed();
	  
	  Assert.assertTrue(result);
	  
	  String capturePath = CommonFunction.captureScreenShotAndGetPath(driver, "hclHomePage");
	  	  
	  log.log(LogStatus.PASS, "User ID check with Screenshot"+log.addScreenCapture(capturePath));
  }
 
  
  
  @AfterMethod
  public void failTests(ITestResult result) {
	  
	  if(result.getStatus()==ITestResult.FAILURE) {
		  log.log(LogStatus.FAIL, "Title check fail");
	  }
	  
	  extent.endTest(log);
	  extent.flush();
	  
  }

  @AfterTest
  public void afterMethod() {
	  
	  driver.quit();
	  
  }
 

}
