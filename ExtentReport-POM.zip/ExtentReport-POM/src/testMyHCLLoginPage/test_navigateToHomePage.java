package testMyHCLLoginPage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import pages.myHCLHomePage;
import utility.MyHCL_Utility;

public class test_navigateToHomePage extends MyHCLBaseTestClass {
	@Test
	public void testNavigateToHomePage() throws IOException {
		myHCLHomePage obj_myHCLHomePage;

		obj_myHCLHomePage = obj_MyHCLLoginPage.navigateToHomePage(driver);
		boolean result = ((obj_myHCLHomePage.verifyHomePageTitle(driver))
				&& (obj_myHCLHomePage.verifyHomePageTitle(driver)));

		Assert.assertTrue(result);
		logger.log(LogStatus.PASS, "Navigate To Home Page Verified successfully");

		logger.log(LogStatus.PASS, "Home page Title Verified successfully");
		String capturePath = MyHCL_Utility.captureScreenShotAndGetPath(driver, "NavigateToHomePage");
		//logger.log(LogStatus.PASS, "testNavigateToHomePage" + logger.addScreenCapture(capturePath));
		logger.log(LogStatus.PASS, driver.getTitle()+logger.addScreenCapture(capturePath));
	}
}
