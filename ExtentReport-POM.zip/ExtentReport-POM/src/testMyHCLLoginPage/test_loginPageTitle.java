package testMyHCLLoginPage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import utility.MyHCL_Utility;

public class test_loginPageTitle extends MyHCLBaseTestClass {
	@Test
	public void testHomePageTitle() throws Exception {
		boolean result = obj_MyHCLLoginPage.verifyLoginPageTitle(driver);

		Assert.assertTrue(result);
		logger.log(LogStatus.PASS, "Login page Title Verified successfully");
		
		String capturePath = MyHCL_Utility.captureScreenShotAndGetPath(driver, "testHomePageTitle");
		//logger.log(LogStatus.PASS, "testHomePageTitle"+logger.addScreenCapture(capturePath));
		logger.log(LogStatus.PASS, driver.getTitle()+logger.addScreenCapture(capturePath));
	}
}
