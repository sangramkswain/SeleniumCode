package testMyHCLLoginPage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import utility.MyHCL_Utility;

public class test_loginPageLaunching extends MyHCLBaseTestClass {
	@Test
	public void loginPageLaunching() throws Exception {
		boolean titleCheck = obj_MyHCLLoginPage.verifyLoginPageTitle(driver);
		boolean elementLoading = obj_MyHCLLoginPage.verifyLoginPageLoading(driver);

		boolean result = (titleCheck && elementLoading);
		Assert.assertTrue(result);
		
		logger.log(LogStatus.PASS, "Login page launching Verified successfully");
		
		String capturePath = MyHCL_Utility.captureScreenShotAndGetPath(driver, "loginPageLaunching");
		//logger.log(LogStatus.PASS, "test_loginPageLaunching"+logger.addScreenCapture(capturePath));
		logger.log(LogStatus.PASS, driver.getTitle()+logger.addScreenCapture(capturePath));
	}
}
