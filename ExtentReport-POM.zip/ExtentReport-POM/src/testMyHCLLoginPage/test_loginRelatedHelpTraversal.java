package testMyHCLLoginPage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import utility.MyHCL_Utility;

public class test_loginRelatedHelpTraversal extends MyHCLBaseTestClass {
	@Test
	public void testLoginScreenTraversal() throws IOException {
		boolean result = obj_MyHCLLoginPage.loginHelpScreenTraversal(driver);
		Assert.assertTrue(result);
		
		logger.log(LogStatus.PASS, "Login Related Help Traversal Successfully");
		
		logger.log(LogStatus.PASS, "Home page Title Verified successfully");
		String capturePath = MyHCL_Utility.captureScreenShotAndGetPath(driver, "testLoginScreenTraversal");
		//logger.log(LogStatus.PASS, "testLoginScreenTraversalt"+logger.addScreenCapture(capturePath));
		logger.log(LogStatus.PASS, driver.getTitle()+logger.addScreenCapture(capturePath));
	}
}
