package testMyHCLHomePage;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import baseTestClass.MyHCLBaseTestClass;
import pages.myHCLHomePage;
import utility.MyHCL_Utility;

public class test_HomePageTitleCheck extends MyHCLBaseTestClass {
	myHCLHomePage obj_myHCLHomePage;

	@Test
	public void testHomePageTitle() throws Exception {
		obj_myHCLHomePage = obj_MyHCLLoginPage.navigateToHomePage(driver);
		boolean result = obj_myHCLHomePage.verifyHomePageTitle(driver);

		Assert.assertTrue(result);
		
		logger.log(LogStatus.PASS, "Home page Title Verified successfully");
		
		String capturePath = MyHCL_Utility.captureScreenShotAndGetPath(driver, "hclHomePage");
		//logger.log(LogStatus.PASS, "Title check pass with Screenshot"+logger.addScreenCapture(capturePath));
		logger.log(LogStatus.PASS, driver.getTitle()+logger.addScreenCapture(capturePath));
	}
}
