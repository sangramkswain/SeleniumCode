package utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyHCL_Utility {

	public static boolean validateWindowTitle(WebDriver driver, String title) {
		boolean result = false;

		if ((driver.getTitle().toString()).equals(title)) {
			result = true;
		}
		return result;
	}

	public static boolean checkElementPresence(WebDriver driver, WebElement element, int time) {
		boolean result = true;

		try {
			WebDriverWait wait = new WebDriverWait(driver, time);
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (org.openqa.selenium.NoSuchElementException e) {
			result = false;
		}
		return result;

	}
	

	public static String captureScreenShotAndGetPath(WebDriver driver, String screenshotName) throws IOException {
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String fotoPath ="D:\\Users\\sangram.swain\\eclipse-workspace\\ExtentReportingDemo\\ScreenShotFolder\\"+screenshotName+".png";
		FileUtils.copyFile(srcFile, new File (fotoPath));
		return fotoPath;
	}

}
