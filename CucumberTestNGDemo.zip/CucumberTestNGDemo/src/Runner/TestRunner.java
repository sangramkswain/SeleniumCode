package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src/featureFiles/testScenario.feature",glue="step_definition",
plugin={"html:target/cucumber_html_report"})
public class TestRunner extends AbstractTestNGCucumberTests  {

}
