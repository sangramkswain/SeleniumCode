package step_definition;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.MyHCLPage;

public class TestMyHCLPage {
	
	MyHCLPage obj_MyHCLPage = new MyHCLPage();
	
	
	@Given("^Browser is open$")
	public void browser_is_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_MyHCLPage.openBrowser();
	    
	}

	@Given("^Browser is pointing to myHCL$")
	public void browser_is_pointing_to_myHCL() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_MyHCLPage.navigateToMYHCL();
	}

	@When("^I enter valid user credetails$")
	public void i_enter_valid_user_credetails() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_MyHCLPage.enterCredentials();
	}

	@When("^set domain to HCLTECH$")
	public void set_domain_to_HCLTECH() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_MyHCLPage.setDomain();
	}

	@When("^click on login button$")
	public void click_on_login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_MyHCLPage.clickLogin();
	}

	@Then("^login should be successful$")
	public void login_should_be_successful() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean result = obj_MyHCLPage.checkHomePageTitle();
		Assert.assertTrue(result);
	    
	}

	@Then("^title of the home page should be My HCL$")
	public void title_of_the_home_page_should_be_My_HCL() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean result = obj_MyHCLPage.checkSuccessfulLogin();
		Assert.assertTrue(result);
	    
	}



}
