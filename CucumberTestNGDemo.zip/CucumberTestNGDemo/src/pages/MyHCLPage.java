package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MyHCLPage {
	WebDriver myHCL_WD;
	
	public void openBrowser() {
		myHCL_WD = new FirefoxDriver();
	}
	
	public void navigateToMYHCL() {
		myHCL_WD.get("https://www.myhcl.com/Login/home.aspx");
	}
	
	public void enterCredentials() {
		myHCL_WD.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("Sangram.Swain");
		myHCL_WD.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("Jaysriram@123");
	}
	
	public void setDomain() {
		myHCL_WD.findElement(By.xpath(".//*[@id='ddlDomain']")).sendKeys("HCLTECH");
	}
	
	public void clickLogin() {
		myHCL_WD.findElement(By.xpath(".//*[@id='btnSubmit']")).click();
	}
	
	public boolean checkSuccessfulLogin() {
		String expectedTitle = "My HCL";
		String actuaTitle = myHCL_WD.getTitle();
		
		boolean result = expectedTitle.equals(actuaTitle);
		return result;
		
	}
	
	public boolean checkHomePageTitle() {
		String expectedTitle = "My HCL";
		String actuaTitle = myHCL_WD.getTitle();
		
		boolean result = expectedTitle.equals(actuaTitle);
		return result;
	}

}
