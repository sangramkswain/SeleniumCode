package step_definition;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.myHCLPage;

public class Test_MYHCLPage {
	myHCLPage obj_myHCLPage;
	
	public Test_MYHCLPage() {
		obj_myHCLPage = new myHCLPage();
	}
	
	@Given("^My browser is open$")
	public void my_browser_is_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_myHCLPage.initBrowser();
	}

	@When("^browser is point to MYHCL PAge$")
	public void browser_is_point_to_MYHCL_PAge() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_myHCLPage.navigateToMYHCL();
	}

	@Then("^Title of the page should be \"([^\"]*)\"$")
	public void title_of_the_page_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean result = obj_myHCLPage.validateTitle();
		Assert.assertTrue(result);
				
	}

	@Then("^user ID and password fields are displayed\\.$")
	public void user_ID_and_password_fields_are_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean result = obj_myHCLPage.UICheck();
		Assert.assertTrue(result);
	    
	}
	
	@When("^user enters valid credentials - \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_valid_credentials_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		obj_myHCLPage.setUserCredentials(arg1, arg2);
	    
	}
	
	@When("^set the domain as \"([^\"]*)\"$")
	public void set_the_domain_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    obj_myHCLPage.setDomain(arg1);
	}



	@When("^click Login Button$")
	public void click_Login_Button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions		
		obj_myHCLPage.clickButton();
	    
	}

	@Then("^User should be successfully logged in$")
	public void user_should_be_successfully_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		boolean result = obj_myHCLPage.checkSuccessfulLogin();
		Assert.assertTrue(result);
	    
	}



	

}
