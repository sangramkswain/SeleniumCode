package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;


public class myHCLPage {
	
	WebDriver myHCL_WD;
	
	public void initBrowser() {
		myHCL_WD = new FirefoxDriver();
	}
	
	public void navigateToMYHCL() {
		myHCL_WD.get("https://www.myhcl.com/Login/home.aspx");
	}
	
	public boolean validateTitle() {
		String expectedTitle = "My HCL Login";
		String actuaTitle = myHCL_WD.getTitle();
		
		boolean result = expectedTitle.equals(actuaTitle);
		return result;	
		
	}
	public boolean UICheck() {
		WebElement uID = myHCL_WD.findElement(By.xpath(".//*[@id='txtUserID']"));
		WebElement pwd = myHCL_WD.findElement(By.xpath(".//*[@id='txtPassword']"));
		boolean userIdPresent = uID.isDisplayed();
		boolean pwPresent = pwd.isDisplayed();
		boolean result = userIdPresent && pwPresent;
		return result;
	}
	
	public void setUserCredentials(String userID, String password) {
		myHCL_WD.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys(userID);
		myHCL_WD.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys(password);
	}
	public void setDomain(String domain) {
		myHCL_WD.findElement(By.xpath(".//*[@id='ddlDomain']")).sendKeys(domain);
	}
	
	public void clickButton() {
		myHCL_WD.findElement(By.xpath(".//*[@id='btnSubmit']")).click();
	}
	
	public boolean checkSuccessfulLogin() {
		String expectedTitle = "My HCL";
		String actuaTitle = myHCL_WD.getTitle();
		
		boolean result = expectedTitle.equals(actuaTitle);
		return result;	
	}

}

