package Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\featurefiles\\testCases.feature",glue="step_definition",
plugin={"html:target/cucumber_html_report"})
public class TestRunner {

}
