package Session_3_listManipulation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class listHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String baseURL = "https://www.myhcl.com/Login/home.aspx";
		
		WebDriver myHCL_WD = new FirefoxDriver();
		
		myHCL_WD.get(baseURL);
		
		WebElement list_WE = myHCL_WD.findElement(By.xpath(".//*[@id='ddlDomain']"));
		
		Select domain_list = new Select(list_WE);
		System.out.println("Multiple element selectable  -> " + domain_list.isMultiple());
		
		//domain_list.selectByIndex(2);
		domain_list.selectByVisibleText("HCLTECH");
		/*
		 * selectByValue()
		 * Not all the drop-downs have the same text and value
		 * Some HTML code may look like
		 * 		<option value = "10"> DELHI </option>
		 * 		<option value = "20"> HYDERABAD </option>
		 * 		<option value = "30"> CHENNAI </option>
		 * 		<option value = "40"> BANGALORE </option>
		 */

	}

}
