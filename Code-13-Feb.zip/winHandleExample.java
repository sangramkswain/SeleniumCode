package Session_5_WindowHandles;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class winHandleExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String url = "https://www.myhcl.com/Login/home.aspx";
		
		WebDriver myHCL_WD = new FirefoxDriver();
		myHCL_WD.get(url);
		
		myHCL_WD.findElement(By.partialLinkText("Help")).click();
		
		String parentHandle = myHCL_WD.getWindowHandle();
		
		
		
	for (String handles: myHCL_WD.getWindowHandles()){
		myHCL_WD.switchTo().window(handles);
			if ((myHCL_WD.getTitle()).equals("Login Related Help")){
				
				myHCL_WD.findElement(By.xpath("//input[@value='Close']")).click();
				
			}
		}
		
		myHCL_WD.switchTo().window(parentHandle);
		myHCL_WD.findElement(By.xpath(".//*[@id='txtUserID']")).sendKeys("Sangram");

	}
}
