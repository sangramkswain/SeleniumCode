package practice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazon_predectiveTextCounting {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		WebDriver amazon_WD;
		String text;
		WebElement list_element;
		
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\ChromeServer\\chromedriver.exe");
		amazon_WD = new ChromeDriver();
		amazon_WD.get("https://www.amazon.com/");
		amazon_WD.findElement(By.xpath(".//*[@id='twotabsearchtextbox']")).sendKeys("Dresses");
		Thread.sleep(2000);
		//*[contains(@attribute, 'value')]
		//tagname[starts-with(@id,'value')]
		List<WebElement> list = amazon_WD.findElements(By.xpath("//*[starts-with(@id,'issDiv')]"));
		//List<WebElement> list = amazon_WD.findElements(By.xpath("//*[contains(@id,'issDiv')]"));
		System.out.println("List zie = " + list.size());
		for (int i = 0; i < list.size(); i++) {
			list_element = list.get(i);
			text = list_element.getAttribute("data-keyword");
			System.out.println("List Element = " + text);
		}
		
		

	}

}
