package Session_3_listManipulation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class listSelectByValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://compendiumdev.co.uk/selenium/basic_html_form.html";
		//WebDriver list_WD = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\ChromeServer\\chromedriver.exe");
				
		WebDriver list_WD = new ChromeDriver();
		list_WD.manage().window().maximize();
		list_WD.get(url);
		
		WebElement list_WE = list_WD.findElement(By.xpath(".//*[@id='HTMLFormElements']/table/tbody/tr[7]/td/select"));
		
		Select list = new Select(list_WE);
		
		list.deselectAll();
		list.selectByValue("ms3");
		list.selectByValue("ms1");
		list.selectByValue("ms2");

	}

}
