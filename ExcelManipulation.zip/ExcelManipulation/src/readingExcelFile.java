import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class readingExcelFile {

	public void readExcel(String filePath, String fileName, String sheetName) throws Exception {
		// Creating an object of File Class to open the excel file
		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file
		FileInputStream inputStream = new FileInputStream(file);

		Workbook workbook = null;

		// TestDataNew - .xlsx
		// Find the file extension by splitting file name in substring and getting only
		// extension name
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		}

		else if (fileExtensionName.equals(".xls")) {
			workbook = new HSSFWorkbook(inputStream);
		}

		// Read sheet inside the workbook by its name
		Sheet sheet = workbook.getSheet(sheetName);

		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		System.out.println("Last Row - " + sheet.getLastRowNum());
		System.out.println("First Row - " + sheet.getFirstRowNum());
		System.out.println("Row Count = " + rowCount);
		System.out.println("Actual Rows - " + sheet.getPhysicalNumberOfRows());

		for (int i = 0; i < rowCount + 1; i++) {
			Row row = sheet.getRow(i);
			for (int j = 0; j < row.getLastCellNum(); j++) {
				System.out.print(row.getCell(j).getStringCellValue() + "\n");
			}
		}

	}

	@Test
	public void readFile() throws Exception {
		readingExcelFile obj_readingExcelFile = new readingExcelFile();
		String filePath = "D:\\Selenium\\Excel";
		obj_readingExcelFile.readExcel(filePath, "TestDataNew.xlsx", "TestData");
		
	}
}
