package utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyHCL_Utility {
	
	
	public static boolean validateWindowTitle(WebDriver driver, String title){
		boolean result = false;
		
		if ((driver.getTitle().toString()).equals(title)){
			result = true;
		}
		return result;
	}
	
	public static boolean checkElementPresence(WebDriver driver, WebElement element, int time){
		boolean result = true;
		
		try{
			WebDriverWait wait = new WebDriverWait(driver, time);
			wait.until(ExpectedConditions.visibilityOf(element));
		}catch (org.openqa.selenium.NoSuchElementException e){
			result = false;
		}
		return result;
		
	}


}
