package testMyHCLHomePage;

import org.junit.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;
import pages.myHCLHomePage;

public class test_HomePageTitleCheck extends  MyHCLBaseTestClass{
	myHCLHomePage obj_myHCLHomePage;
  @Test
  public void testHomePageTitle() {
	  obj_myHCLHomePage = obj_MyHCLLoginPage.navigateToHomePage(driver);
	  boolean result = obj_myHCLHomePage.verifyHomePageTitle(driver);
	  
	  Assert.assertTrue(result);
  }
}
