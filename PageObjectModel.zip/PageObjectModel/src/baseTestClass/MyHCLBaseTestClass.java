package baseTestClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import pages.MyHCLLoginPage;

public class MyHCLBaseTestClass {
	
	public MyHCLLoginPage obj_MyHCLLoginPage;
	public WebDriver driver;
	
	@BeforeMethod
	public void intiTestSuite() {
		driver = new FirefoxDriver();
		driver.get("https://www.myhcl.com/Login/home.aspx");
		obj_MyHCLLoginPage = PageFactory.initElements(driver, MyHCLLoginPage.class);		
	}
	
	@AfterMethod
	public void cleanUP() {
		driver.quit();
	}

}
