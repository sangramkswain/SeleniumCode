package testMyHCLLoginPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;


public class test_loginPageLaunching extends MyHCLBaseTestClass{
  @Test
  public void testHomePageLoading() {
	  boolean titleCheck = obj_MyHCLLoginPage.verifyLoginPageTitle(driver);
	  boolean elementLoading = obj_MyHCLLoginPage.verifyLoginPageLoading(driver);
	  
	 boolean result = (titleCheck && elementLoading);
	  Assert.assertTrue(result);
  }
}
