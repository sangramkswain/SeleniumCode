package testMyHCLLoginPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import baseTestClass.MyHCLBaseTestClass;

public class test_loginRelatedHelpTraversal extends MyHCLBaseTestClass{
  @Test
  public void testLoginScreenTraversal() {
	  boolean result = obj_MyHCLLoginPage.loginHelpScreenTraversal(driver);
	  Assert.assertTrue(result);
  }
}
